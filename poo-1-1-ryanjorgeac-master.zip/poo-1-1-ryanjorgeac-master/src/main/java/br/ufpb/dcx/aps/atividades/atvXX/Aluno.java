package br.ufpb.dcx.aps.atividades.atvXX;

public class Aluno {

    public String matricula;
    public String nomeAluno;

    public Aluno(String matricula, String nomeAluno){
        this.matricula = matricula;
        this.nomeAluno = nomeAluno;
    }



}
